For C++:
- install Visual Studio 2012 (Express)
    = used third party libs:
        ~ boost: http://www.boost.org
        ~ websocketpp: https://github.com/zaphoyd/websocketpp
- on page http://<server>/codenjoy-contest/help
    ~ you can read game instructions
        # server = ip:8080 server ip inside your LAN
        # server = codenjoy.com if you play on http://codenjoy.com/codenjoy-contest
- register your hero on server http://<server>/codenjoy-contest/register
- open bomberman.sln in Visual Studio
- change yourName in main.cpp from "_bot_" to your one
- implement your bot in YourDirectionSolver class.
    = you can use our DumbDirectionSolver implementation as an example
- compile solution and launch
- Codenjoy!



