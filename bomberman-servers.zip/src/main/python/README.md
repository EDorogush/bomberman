bomberman
=========

websocket client app for Codenjoy Bomberman

Designed to be run with python3
Depends on websocket-client from https://github.com/liris/websocket-client/blob/py3/websocket.py

The bomberman actions logic should be extended by modifying the find_direction method in dds.py
or by calling your own method from get() in the same dds.py
